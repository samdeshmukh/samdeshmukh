from django.urls import path
from core import views

appname = 'core'
urlpatterns = [
    path('', views.index, name='index'),  # Landing page
    path('contact/', views.contact, name='contact'),
    path('coming-soon/', views.coming_soon, name='coming_soon'),
    path('career/', views.career, name='career'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('data/', views.data, name='data'),
    path('flow', views.flow, name='flow'),
    # Other URL patterns for your app
]
