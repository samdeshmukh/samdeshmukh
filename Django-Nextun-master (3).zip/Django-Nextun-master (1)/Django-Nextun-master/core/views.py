from collections import UserDict
from django.contrib.auth import authenticate, login as auth_login
from django.shortcuts import render, redirect
from django.http import HttpResponse

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('http://127.0.0.1:8000/career')  # Redirect to the career page
        else:
            return HttpResponse("Username or Password is incorrect!!!")
    else:
        return render(request, 'login.html')



def register(request):
    if request.method == 'POST':
        uname=request.POST.get('username')
        password=request.POST.get('password')
        confirm_password=request.POST.get('confirm_password')
        if password!=confirm_password:
            return HttpResponse("Your password and confirm password are not same!!")
        else:
    
         my_user=UserDict.objects.create_user(uname,password,confirm_password)
         my_user.save()
        return redirect('http://127.0.0.1:8000/login')
    else:
        # Display registration form
        return render(request, 'register.html')



def index(request):
    return render(request, 'index.html')

def career(request):
    return render(request, 'career.html')


def contact(request):
    if request.method == 'POST':
        # Process the form data
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        message = request.POST.get('message')
    return render(request, 'contact.html')

def flow(request):
    return render(request, 'flow.html')



from django.shortcuts import render

def data(request):
    data = {'key': 'value'}
    return render(request, 'data.html', data)

# Your other view functions here


def coming_soon(request):
    return render(request, 'coming_soon.html')





