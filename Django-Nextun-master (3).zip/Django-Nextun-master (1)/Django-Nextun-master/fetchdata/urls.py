from django.urls import path
from fetchdata import views

appname = 'fetchdata'
urlpatterns = [
    path('twitterfetch', views.twitterfetch, name='twitterfetch'),
    path('save_database_settings/', views.save_database_settings, name='save_database_settings'),
    path('eda/', views.eda_view, name='eda_view'),
    path('flow', views.flow, name='flow'),
    
]