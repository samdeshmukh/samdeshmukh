from django.shortcuts import render , redirect 
from django.views import View
import pandas as pd

def twitterfetch(request):
    return render(request, "twitterform.html")

from django.conf import settings
from django.db import connection

def save_database_settings(request):
    if request.method == 'POST':
        db_host = request.POST.get('db_host')
        db_port = request.POST.get('db_port')
        db_name = request.POST.get('db_name')
        db_user = request.POST.get('db_user')
        db_password = request.POST.get('db_password')
        query = request.POST.get('query')

        # Update the DATABASES dictionary in settings.py
        settings.DATABASES['default'] = {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': db_name,
            'USER': db_user,
            'PASSWORD': db_password,
            'HOST': db_host,
            'PORT': db_port,
        }
        if query:
            try:
                # Execute the query and fetch the data
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    data = cursor.fetchall()
            except Exception as e:
                # Render the same page with the error message
                return render(request, "twitterform.html", {'error_message': str(e)})

            # Render the next_page.html template with the fetched data
            return render(request, 'next_page.html', {'data': data})

    # Handle the case when the request method is not POST or no query is provided
    return render(request, 'next_page.html', {'error_message': 'Invalid request.'})
       
def eda_view(request):
    data = pd.read_csv('C:\\Users\\prakr\\Documents\\Nextun\\nextun\\DatasetF.csv')
    # plot sentiments of csv file
    import matplotlib.pyplot as plt
    import seaborn as sns
    sns.set_style('whitegrid')
    plt.figure(figsize=(10, 6))
    sns.countplot(x='sentiment', data=data)
    plt.xlabel('sentiment')
    plt.ylabel('Count')
    plt.title('Sentiment Count')
    plt.savefig('C:\\Users\\prakr\\Documents\\Nextun\\nextun\\fetchdata\\static\\sentiment_count.png')
    plt.close()
    return render(request, 'eda.html')


def flow(request):
    if request.method == 'POST':
        db_host = request.POST.get('db_host')
        db_port = request.POST.get('db_port')
        db_name = request.POST.get('db_name')
        db_user = request.POST.get('db_user')
        db_password = request.POST.get('db_password')
        query = request.POST.get('query')

        # Update the DATABASES dictionary in settings.py
        settings.DATABASES['default'] = {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': db_name,
            'USER': db_user,
            'PASSWORD': db_password,
            'HOST': db_host,
            'PORT': db_port,
        }

        if query:
            try:
                # Execute the query and fetch the data
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    data = cursor.fetchall()
            except Exception as e:
                # Render the same page with the error message
                return render(request, "flow.html", {'error_message': str(e)})

        # Redirect to a success page or any other desired page
        return redirect('success')  # Replace 'success' with the actual URL name of the success page

    else:
        # Render the form
        return render(request, 'flow.html')


def save_database_settings(request):
    if request.method == 'POST':
        db_host = request.POST.get('db_host')
        db_port = request.POST.get('db_port')
        db_name = request.POST.get('db_name')
        db_user = request.POST.get('db_user')
        db_password = request.POST.get('db_password')
        query = request.POST.get('query')

        # Update the DATABASES dictionary in settings.py
        settings.DATABASES['default'] = {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': db_name,
            'USER': db_user,
            'PASSWORD': db_password,
            'HOST': db_host,
            'PORT': db_port,
        }

        if query:
            try:
                # Execute the query and fetch the data
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    data = cursor.fetchall()
            except Exception as e:
                # Render the same page with the error message
                return render(request, "flow.html", {'error_message': str(e)})

        # Redirect to a success page or any other desired page
        return redirect('success')  # Replace 'success' with the actual URL name of the success page

