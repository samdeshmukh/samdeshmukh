from django.urls import path
from .views import data_view

app_name = 'dataform'  # App name

urlpatterns = [
    path('data/', data_view, name='data'),
    # Other URL patterns for your app
]
