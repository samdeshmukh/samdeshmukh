from django.shortcuts import render

def data_view(request):
    # Logic to retrieve data or perform any other necessary operations
    # You can pass data to the template using a dictionary
    data = {'key': 'value'}

    # Render the template with the data
    return render(request, 'data.html', data)







