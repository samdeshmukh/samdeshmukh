from django.urls import path
from fetchdata import views

appname = 'fetchdata'
urlpatterns = [
    path('googleanalyticfetch', views.googleanalyticfetch, name='googleanalyticfetch'),
    path('save_database_settings/', views.save_database_settings, name='save_database_settings'),
    
]