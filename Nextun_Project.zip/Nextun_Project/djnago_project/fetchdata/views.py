from django.shortcuts import render , redirect 
from django.views import View
import pandas as pd

def googleanalyticfetch(request):
    return render(request, "googleanalytic.html")

from django.conf import settings
from django.db import connection

def save_database_settings(request):
    if request.method == 'POST':
        db_host = request.POST.get('db_host')
        db_port = request.POST.get('db_port')
        db_name = request.POST.get('db_name')
        db_user = request.POST.get('db_user')
        db_password = request.POST.get('db_password')
        query = request.POST.get('query')

        # Update the DATABASES dictionary in settings.py
        settings.DATABASES['default'] = {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': db_name,
            'USER': db_user,
            'PASSWORD': db_password,
            'HOST': db_host,
            'PORT': db_port,
        }
        if query:
            try:
                # Execute the query and fetch the data
                with connection.cursor() as cursor:
                    cursor.execute(query)
                    data = cursor.fetchall()
            except Exception as e:
                # Render the same page with the error message
                return render(request, "googleanalytic.html", {'error_message': str(e)})

            # Render the next_page.html template with the fetched data
            return render(request, 'next_page.html', {'data': data})

    # Handle the case when the request method is not POST or no query is provided
    return render(request, 'next_page.html', {'error_message': 'Invalid request.'})
       

