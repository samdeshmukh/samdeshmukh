from django.shortcuts import render , redirect 
from django.views import View

def login(request):
    return render(request, 'login.html')

def register(request):
    return render(request, 'register.html')


def index(request):
    return render(request, 'index.html')

def career(request):
    return render(request, 'career.html')

def contact(request):
    if request.method == 'POST':
        # Process the form data
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        message = request.POST.get('message')
        
        # Perform desired actions with the form data
        
        return render(request, 'contact_success.html')
    
    return render(request, 'contact.html')

def coming_soon(request):
    return render(request, 'coming_soon.html')





